<template>
<div class="mt-5 bg-secondary">
        <div class="container">
          <div class="d-flex justify-content-between bg-secondary pt-4">
            <b-col><h3>BYXMART</h3></b-col>
            <b-col>
              <b-col><span class="float-right">Developed by Bayu Bimantoro</span></b-col>
            </b-col>
          </div>
        </div>
      </div>
</template>

<script>
export default {
  name: 'Footer',
  data: function () {
    return {
      show: true
    }
  }
}
</script>
